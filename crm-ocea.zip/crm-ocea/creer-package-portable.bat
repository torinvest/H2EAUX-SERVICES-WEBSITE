@echo off
cd /d "%~dp0"
echo.
echo  Creation du package ZIP portable...
echo  (OneDrive bloque les .bat : utilisez le ZIP sur l'autre PC)
echo.

for /f "delims=" %%f in ('python make_portable.py') do set ZIP=%%f

if exist "%ZIP%" (
  echo.
  echo  OK - Fichier cree sur le Bureau :
  echo  %ZIP%
  echo.
  echo  Copiez ce ZIP sur clé USB ou envoyez-le par mail.
  echo  Sur l'autre PC : clic droit ^> Extraire tout ^> installer.bat
  echo.
  explorer /select,"%ZIP%"
) else (
  echo  ERREUR - Python requis.
)
pause
