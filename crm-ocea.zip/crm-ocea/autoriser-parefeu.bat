@echo off
:: A lancer UNE FOIS en clic droit > Executer en tant qu'administrateur
echo.
echo  Autorisation pare-feu Windows - CRM H2EAUX port 8080
echo.

netsh advfirewall firewall delete rule name="CRM H2EAUX SERVICES" >nul 2>&1
netsh advfirewall firewall add rule name="CRM H2EAUX SERVICES" dir=in action=allow protocol=TCP localport=8080 profile=private,domain

if %errorlevel% equ 0 (
  echo  OK - Le port 8080 est autorise pour les autres PC du reseau.
) else (
  echo  ERREUR - Relancez ce fichier en ADMINISTRATEUR ^(clic droit^).
)
echo.
pause
