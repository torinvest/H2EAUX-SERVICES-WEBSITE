@echo off
:: Alias - meme chose que demarrer.bat
call "%~dp0demarrer.bat"
