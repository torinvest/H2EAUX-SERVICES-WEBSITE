"""Crée un ZIP portable du CRM pour copier sur clé USB ou autre PC."""
import zipfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).parent
DESKTOP = Path.home() / "Desktop"

LISEZMOI = """CRM H2EAUX SERVICES — Entreprise OCEA
Comptages immobiliers et maintenances
========================================

DEUX CAS D'USAGE
----------------

A) CONSULTER le CRM depuis un autre PC (sans installer)
   → PAS besoin de copier ce dossier !
   → Sur le PC principal : lancez demarrer.bat
   → Sur l'autre PC : ouvrez Chrome et tapez l'adresse affichée
     exemple : http://192.168.1.15:8080
   → Les fichiers .bat ne servent QUE sur le PC principal.

B) INSTALLER le CRM sur un autre PC
   1. Décompressez ce ZIP (clic droit > Extraire tout)
   2. Installez Python 3.10+ depuis python.org si absent
   3. Double-cliquez installer.bat
   4. Clic droit autoriser-parefeu.bat > Exécuter en administrateur
   5. Double-cliquez demarrer.bat

DOSSIER HOC
-----------
Copiez aussi le dossier HOC (Harmonie) à côté de CRM_H2EAUX :
  Bureau/OCEA/HOC/
  Bureau/OCEA/CRM_H2EAUX/   (ce dossier)

OneDrive bloque souvent les .bat : utilisez toujours le ZIP, jamais
copier les .bat un par un depuis le navigateur OneDrive.
"""


def build_portable_zip() -> tuple:
    """Retourne (contenu zip, nom fichier)."""
    import io

    buf = io.BytesIO()
    skip = {"make_portable.py"}
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("CRM_H2EAUX/LISEZMOI.txt", LISEZMOI)
        for path in ROOT.rglob("*"):
            if not path.is_file():
                continue
            if "__pycache__" in path.parts or path.suffix == ".zip":
                continue
            if path.name in skip:
                continue
            arc = Path("CRM_H2EAUX") / path.relative_to(ROOT)
            zf.write(path, arc.as_posix())
    name = f"CRM_H2EAUX_portable_{datetime.now().strftime('%Y%m%d')}.zip"
    return buf.getvalue(), name


def main():
    DESKTOP.mkdir(parents=True, exist_ok=True)
    content, name = build_portable_zip()
    out = DESKTOP / name
    out.write_bytes(content)
    print(str(out))
    return out


if __name__ == "__main__":
    main()
