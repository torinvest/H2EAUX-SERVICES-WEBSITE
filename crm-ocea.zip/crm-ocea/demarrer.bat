@echo off
cd /d "%~dp0"

echo.
echo  ========================================
echo   CRM H2EAUX SERVICES - Entreprise OCEA
echo   Mode RESEAU - autres PC autorises
echo  ========================================
echo.

for /f "delims=" %%i in ('python -c "import socket; s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s.connect(('8.8.8.8',80)); print(s.getsockname()[0]); s.close()" 2^>nul') do set LAN_IP=%%i

echo  Sur CE PC    : http://127.0.0.1:8080
if defined LAN_IP (
  echo  AUTRE PC     : http://%LAN_IP%:8080
  echo.
  echo  ^> Tapez cette adresse dans le navigateur de l'autre PC
) else (
  echo  AUTRE PC     : voir la banniere verte dans le CRM
)
echo.
echo  Si ca ne marche pas : clic droit sur autoriser-parefeu.bat
echo                        ^> Executer en tant qu'administrateur
echo.

python -m uvicorn app:app --host 0.0.0.0 --port 8080 --reload
