@echo off
cd /d "%~dp0"
echo Installation CRM H2EAUX SERVICES...
python --version >nul 2>&1 || (
  echo.
  echo  Python non installe. Telechargez-le sur https://www.python.org/downloads/
  echo  Cochez "Add Python to PATH" lors de l'installation.
  pause
  exit /b 1
)
pip install -r requirements.txt
echo.
echo  Installation terminee. Lancez demarrer.bat
pause
